### Database Technologies & Management

#### MongoDB

* Data Wrangling with Mongo DB [Udacity Course](https://www.udacity.com/course/ud032)

#### PostgreSQL
* [PostgreSQL](https://pypi.python.org/pypi/psycopg2)
